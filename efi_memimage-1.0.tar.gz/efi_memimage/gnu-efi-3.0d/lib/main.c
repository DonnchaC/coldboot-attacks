#include "lib.h"

INTERFACE_DECL(moo);
