#define NPPP 1
